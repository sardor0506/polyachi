
# users = {'1923569602': {'name': 'sardor 1', 'nomer': '+998889190506'}, '7223024122': {'name': 'fugg', 'nomer': '+998918119794'}}

# polya_vaqt = {
#     'kun_vaqt':{'kun':"29-Iyul", 'soat':'20:00-19:00', 'buyurtmachi': users},
#     '11111111':{'kun':"29-Iyul", 'soat':'20:00-19:00', 'buyurtmachi': users},
#     '22222222':{'kun':"29-Iyul", 'soat':'20:00-19:00', 'buyurtmachi': users},
#     '33333333':{'kun':"29-Iyul", 'soat':'20:00-19:00', 'buyurtmachi': users},
#     '66666666':{'kun':"29-Iyul", 'soat':'20:00-19:00', 'buyurtmachi': users},
#     '44444444':{'kun':"29-Iyul", 'soat':'20:00-19:00', 'buyurtmachi': users},
#     '55555555':{'kun':"29-Iyul", 'soat':'20:00-19:00', 'buyurtmachi': users}
#     }


# def get_data():
#     malumot = f""
#     for id, info in polya_vaqt.items():
#         name = info['name']
#         nomer = info['nomer']
#         malumot+=f"ID: {id}\nIsm: {name}\nTelefon: {nomer}\n"
#     return malumot
# def get_data():
#     malumot = f""
#     for id, info in polya_vaqt.items():
#         print(id, info)
#         print()
#         print()

# print(get_data())

# users = {
#     '1923569602': {'name': 'sardor 1', 'nomer': '+998889190506'},
#     '7223024122': {'name': 'fugg', 'nomer': '+998918119794'}
# }

# polya_vaqt = {
#     'kun_vaqt': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': users},
#     '11111111': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': users},
#     '22222222': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': users},
#     '33333333': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': users},
#     '66666666': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': users},
#     '44444444': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': users},
#     '55555555': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': users}
# }

# def print_malumotlar(polya_vaqt):
#     for key, value in polya_vaqt.items():
#         print(f"Malumotlar for {key}:")
#         print(f"Olingan vaqt: {value['kun']} {value['soat']}")
#         print("Buyurtmachi:")
#         for user_id, user_info in value['buyurtmachi'].items():
#             print(f"  ID: {user_id}")
#             print(f"  Name: {user_info['name']}")
#             print(f"  Nomer: {user_info['nomer']}")
#         print("\n")

# print(print_malumotlar(polya_vaqt))

# users = {
#     '1923569602': {'name': 'sardor 1', 'nomer': '+998889190506'},
#     '7223024122': {'name': 'fugg', 'nomer': '+998918119794'}
# }

# polya_vaqt = {'kun_vaqt': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': users}}

# def print_malumotlar(polya_vaqt, user):
#     for key, value in polya_vaqt.items():
#         user_info = value['buyurtmachi'][user]
#         k = f"Malumotlar for {key}:\nOlingan vaqt: {value['kun']} {value['soat']}\n\nBuyurtmachi:\n  Name: {user_info['name']}\n  Nomer: {user_info['nomer']}")
#     return k