from aiogram.types import Message, CallbackQuery, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram import Bot
from datetime import datetime, timedelta
import calendar
import data
import keyboards
import main
import admin

def sana_kunlar():
    hozirgi_vaqt = datetime.now()
    yil = hozirgi_vaqt.year
    oy = hozirgi_vaqt.month
    kun = hozirgi_vaqt.day

    oylar = [
        "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
        "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr"
    ]
    
    sana = []
    
    for i in range(7):
        yangi_vaqt = hozirgi_vaqt + timedelta(days=i)
        yangi_kun = yangi_vaqt.day
        yangi_oy = yangi_vaqt.month
        sana.append(f"{yangi_kun:02d}-{oylar[yangi_oy - 1]}")
    return sana


async def kunlar_inline(callback_data:CallbackQuery):
    tugma = InlineKeyboardBuilder()

    for i in sana_kunlar():
        tugma.button(text=i, callback_data=i)
    tugma.adjust(3)
    tugma.add(InlineKeyboardButton(text='◀️ Orqaga', callback_data='nima'))

    tugma = tugma.as_markup()
    matn = f"""📅 Kerakli sanani tanlang:"""
    await callback_data.message.delete()
    await callback_data.message.answer(text=matn, reply_markup=tugma)

vaqt_polya_tolga = ['19:00-20:00', '20:00-21:00', '21:00-22:00', '22:00-23:00', '23:00-00:00', '00:00-01:00']


def soat_inline(selected_day):
    malumot = []
    tugma = InlineKeyboardBuilder()
    print(selected_day,'soat_inline')
    for i in vaqt_polya_tolga:
        tugma.button(text=i, callback_data=f"{selected_day}-{i}-*")
    b_kuni = selected_day
    tugma.button(text='◀️ Orqaga', callback_data='sana_tanlash')
    tugma.adjust(3)
    tugma = tugma.as_markup()
    malumot.append(tugma)
    malumot.append(b_kuni)
    return malumot


async def soatlar_inline(callback_data:CallbackQuery): #o'ziga qaytarish mumkin emas chunki data_v bekoor qilish bo'lib qoladi
    await callback_data.message.delete()
    selected_day = callback_data.data
    print(selected_day)
    matn = f"{selected_day} kuni qaysi vaqtda o'ynamoqchisiz? ⏳\n\nKerakli vaqtni tanlang..! "
    await callback_data.message.answer(text=matn, reply_markup=soat_inline(selected_day)[0])


async def soat_buyurtma(callback_data:CallbackQuery):
    data_v = callback_data.data.split('-')
    kun_vaqt = f"{data_v[0]}-{data_v[1]}-{data_v[2]}-{data_v[3]}-&"
    if data.tek(polya_vaqt=data.polya_vaqt, data_v=data_v):
        await callback_data.answer(text=f'{data_v[2]}-{data_v[3]} olingan ❌')
    else:
        await callback_data.message.delete()
        tugmal = InlineKeyboardBuilder()
        tugmal.button(text='Buyurtma berish ✅', callback_data=kun_vaqt)
        tugmal.button(text='Bekor qilish ❌', callback_data='orqaaa')
        tugmal=tugmal.as_markup()
        matn = f"ma'lumot\n\nSana : {data_v[0]}-{data_v[1]}\nBoshlanish vaqti : {data_v[2]}\nTugatish : {data_v[3]}"
        await callback_data.message.answer(text=matn, reply_markup=tugmal)


async def xabar_tasdiq(callback_data:CallbackQuery, bot:Bot):
    user = callback_data.from_user.id
    data_v = callback_data.data.split('-')
    xabar_tasdiq_func(data_v=data_v, callback_data=callback_data, user=user)
    xabar =data.buyurtma_gtv(polya_vaqt=data.polya_vaqt, user=str(user))
    admin_answer = f"Yangi buyurtma ✅\n\n{xabar}"
    bosh = InlineKeyboardBuilder()
    bosh.button(text='🏡 Bosh menu', callback_data='bosh_menu')
    bosh = bosh.as_markup()
    await callback_data.message.delete()
    await bot.send_message(chat_id=main.admin_id, text=admin_answer)
    await callback_data.message.answer(text=f'Buyurtma qabul qilindi ✅\n\n{xabar}', reply_markup=bosh)


def xabar_tasdiq_func(data_v,callback_data, user):
    kun = f"{data_v[0]}-{data_v[1]}"
    soat = f"{data_v[2]}-{data_v[3]}"
    data.polya_vaqt[str(callback_data.data)] = {'kun':kun, 'soat':soat, 'buyurtmachi':user, 'baza': data.users}


async def chaqa(callback_data:CallbackQuery):
    await callback_data.answer(text='Hozircha mavjud emas 😔')


kunlar = InlineKeyboardBuilder()
for i in sana_kunlar():
    kunlar.button(text=i, callback_data=i+'^')
kunlar.row(InlineKeyboardButton(text='◀️ Orqaga', callback_data='data_admin'), width=2)
kunlar.adjust(2)
kunlar = kunlar.as_markup()


inline_admin = InlineKeyboardBuilder()
inline_admin.button(text='◀️ Orqaga', callback_data='kun_list')
inline_admin = inline_admin.as_markup()



async def admin_xabar(callback_data:CallbackQuery):
    matn = ''
    tanlangan_kun = callback_data.data[:-1]
    buyurtmalar = admin.get_booking_details(day=tanlangan_kun)
    if buyurtmalar:
        matn+=f"{tanlangan_kun} uchun buyurtmalar:\n\n"
        for idx, buyurtma in enumerate(buyurtmalar, 1):
            matn+=f"<b>Buyurtma #{idx}:</b>\n"
            matn+=f"<b>     Kun: {buyurtma['kun']}</b>\n"
            matn+=f"<b>     Soat: {buyurtma['soat']}</b>\n"
            matn+=f"<b>     Buyurtmachi: {buyurtma['name']}</b>\n"
            matn+=f"<b>     Tel Nomer: {buyurtma['phone']}</b>\n"
            matn+="    --------------\n"
    else:
        matn+=f"{tanlangan_kun} uchun hech qanday buyurtma topilmadi."
    await callback_data.message.delete()
    await callback_data.message.answer(text=matn, parse_mode="HTML", reply_markup=inline_admin )



async def iniline_kun_xabar(callback_data:CallbackQuery):
    await callback_data.message.delete()
    await callback_data.message.answer(text=f"Qaysi kunni ko'rmoqchisiz", reply_markup=kunlar)


async def inline_data_admin(callback_data:CallbackQuery):
    await callback_data.message.delete()
    inline_main = InlineKeyboardBuilder()
    inline_main.button(text='Tekshirish', callback_data='haaa')
    inline_main.button(text='◀️ Orqaga', callback_data='bosh_menu')
    inline_main = inline_main.as_markup()
    matn = f"Admin panel\n\nkerakli tugmadan foydalaning\nTekshiris ==> "
    await callback_data.message.answer(text=matn, reply_markup=inline_main)


