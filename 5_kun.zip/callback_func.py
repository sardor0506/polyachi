from aiogram import F, Bot
from aiogram.types import CallbackQuery, Message
from aiogram.types.input_file import InputFile
import keyboards
import data
import asyncio
from datetime import datetime
import calendar
import main



async def polya_tolga(callback_data:CallbackQuery):
    await callback_data.message.delete()
    image = 'https://t.me/eshmatovsardor0506/116'
    matn = (f'''
🏟 Koson tumani Yuksalish mahallasida joylashgan stadionlar

1-stadion
   - Polyachi: Familya Ism
   - Polyachi bilan aloqa 📞: +998 90 313 0911

2-stadion
   - Polyachi: Familya Ism
   - Polyachi bilan aloqa 📞: +998 90 313 0911''')
    await callback_data.message.answer_photo(photo=image, caption=matn, reply_markup= keyboards.inline_tolga_stadion)


async def polya_tolga_2(callback_data:CallbackQuery):
    await callback_data.answer(text='')


async def bosh_menu(callback_data:CallbackQuery):
    await callback_data.message.delete()
    await callback_data.message.answer(text="Qayerda o'ynamoqchisiz hududingizni tanlang..",reply_markup=keyboards.inline_hudud)



