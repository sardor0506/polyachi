from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, BotCommand
from aiogram.filters import CommandStart,Command, or_f
from asyncio import run
import func
import states
import keyboards
import callback_func
import callback_func_tugma
from aiogram.fsm.state import State


admin_id = '6209960731'
TOKEN = '7332222895:AAHz1owu60_PeiUBtlNu-ELWPnBbxeppH6A'
dp = Dispatcher()

async def start_bot_answer(bot: Bot):
    await bot.send_message(chat_id='6209960731', text='Bot ishga tushirildi')

async def stop_bot_answer(bot: Bot):
    await bot.send_message(chat_id='6209960731', text='Bot to\'xtatildi')

async def start():
    dp.startup.register(start_bot_answer)
    dp.message.register(func.start_xabari, CommandStart())
    dp.callback_query.register(callback_func_tugma.inline_data_admin, F.data=='admin')
    dp.message.register(func.get_nomer, states.sign_up.name)
    dp.message.register(func.info_answer, states.sign_up.nomer)
    dp.callback_query.register(callback_func.polya_tolga, F.data=='tolga')
    dp.callback_query.register(callback_func_tugma.kunlar_inline, F.data=='polya1')
    dp.callback_query.register(callback_func_tugma.soatlar_inline, or_f(F.data==callback_func_tugma.sana_kunlar()[0], F.data==callback_func_tugma.sana_kunlar()[1],F.data==callback_func_tugma.sana_kunlar()[2],F.data==callback_func_tugma.sana_kunlar()[3],F.data==callback_func_tugma.sana_kunlar()[4],F.data==callback_func_tugma.sana_kunlar()[5]))
    dp.callback_query.register(callback_func.bosh_menu, F.data=='bosh_menu')
    dp.callback_query.register(callback_func_tugma.soat_buyurtma, or_f(F.data[-1]=='*'))
    dp.callback_query.register(callback_func.polya_tolga, F.data=='orqaga_t')
    dp.callback_query.register(callback_func_tugma.xabar_tasdiq, F.data[-1]=='&')
    dp.callback_query.register(callback_func_tugma.kunlar_inline, F.data=='orqaaa')
    dp.callback_query.register(callback_func.polya_tolga, F.data=='nima')
    dp.callback_query.register(callback_func_tugma.kunlar_inline, F.data=='sana_tanlash')
    dp.callback_query.register(callback_func.bosh_menu, F.data=='start_habar')
    dp.callback_query.register(callback_func_tugma.chaqa, or_f(F.data=='chaqa',F.data=='polya2'))
    dp.callback_query.register(callback_func_tugma.admin_xabar, F.data[-1]=='^')
    dp.callback_query.register(callback_func_tugma.iniline_kun_xabar, F.data=='haaa')
    dp.callback_query.register(callback_func_tugma.iniline_kun_xabar, F.data=='kun_list')
    dp.callback_query.register(callback_func_tugma.inline_data_admin, F.data=='data_admin')
    dp.shutdown.register(stop_bot_answer)
    bot = Bot(TOKEN)
    await bot.set_my_commands([
        BotCommand(command='/start', description='Botni ishga tushirish'), 
        BotCommand(command='/help', description='Yordam')
    ])
    await dp.start_polling(bot)

if __name__ == '__main__':
    run(start())
