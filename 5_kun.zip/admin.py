from aiogram.types import CallbackQuery
import data


def get_booking_details(day):
    bookings = data.polya_vaqt
    result = []

    for key, value in bookings.items():
        if value['kun'] == day:
            user_id = value['buyurtmachi']
            print(user_id, 'id')
            user_info = data.users.get(str(user_id), {})
            name = user_info.get('name', 'Noma\'lum')
            print(user_info, 'user info')
            phone = user_info.get('nomer', 'Noma\'lum')
            result.append({
                'kun': value['kun'],
                'soat': value['soat'],
                'buyurtmachi': user_id,
                'name': name,
                'phone': phone
            })
    return result


