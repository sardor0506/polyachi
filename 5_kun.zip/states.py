from aiogram.fsm.state import State, StatesGroup

class sign_up(StatesGroup):
    name = State()
    nomer = State()

