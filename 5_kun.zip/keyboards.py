from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
import data
from datetime import datetime
import calendar


contakt = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text='nomer ulashish', request_contact=True)
        ]
    ],
    resize_keyboard=True,
    is_persistent=True
)

inline_hudud= InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text='Yuksalish', callback_data='tolga')
        ],
        [
            InlineKeyboardButton(text='Chaqa', callback_data='chaqa')
        ],
        [
            InlineKeyboardButton(text='admin', callback_data='admin')
        ]
    ]
)

inline_tolga_stadion = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text='1-polya', callback_data='polya1'),
            InlineKeyboardButton(text='2-polya', callback_data='polya2')
        ],
        [
            InlineKeyboardButton(text='◀️ Orqaga', callback_data='start_habar')        ]
    ]
)




inlini_buyurtma_tastiqla = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text='Buyurtma berish ✅', callback_data='tasdiq_tolga'),
            InlineKeyboardButton(text='Bekor qilish ❌', callback_data='bekor_tolga'),
        ]
    ]
)

# inline_tolga_stadion_polya = InlineKeyboardMarkup(
#     inline_keyboard=[
#         [
#             InlineKeyboardButton(text='Joy olish 📨', callback_data='olinadi')
#         ],
#         [
#             InlineKeyboardButton(text='Stadion xolati ⚡️', callback_data='holat'),
#             InlineKeyboardButton(text='Stadion lacatsiyasi', callback_data='locat_t')
#         ],
#         [
#             InlineKeyboardButton(text='◀️ Orqaga', callback_data='orqaga_t'),
#             InlineKeyboardButton(text='🏡 Bosh menu', callback_data='bosh_menu')
#         ]
#     ]
# )






# inline_soat_tolga_1 = InlineKeyboardMarkup(
#     inline_keyboard=[
#         [
#         InlineKeyboardButton(text='19:00-20:00',callback_data=f'19:00-20:00'),
#         InlineKeyboardButton(text='20:00-21:00',callback_data='20:00-21:00'),
#         InlineKeyboardButton(text='21:00-22:00',callback_data='21:00-22:00'),
#     ],
#     [
#         InlineKeyboardButton(text='22:00-23:00',callback_data='22:00-23:00'),
#         InlineKeyboardButton(text='23:00-00:00',callback_data='23:00-00:00'),
#         InlineKeyboardButton(text='00:00-01:00',callback_data='00:00-01:00'),
        
#     ] ,
#     [
#         InlineKeyboardButton(text='◀️ Orqaga', callback_data='orqaga_vaqt_tolga'),
#         InlineKeyboardButton(text='🏡 Bosh menu', callback_data='bosh_menu')            
#     ]
# ])

# inline_tolga_stadion_polya_sana = InlineKeyboardMarkup(
#     inline_keyboard=[
#         [
#             InlineKeyboardButton(text=data.sana_kunlar()[0], callback_data=f"0"),
#             InlineKeyboardButton(text=data.sana_kunlar()[1], callback_data=f"1"),
#             InlineKeyboardButton(text=data.sana_kunlar()[2], callback_data=f"2")
#         ],
#         [
#             InlineKeyboardButton(text=data.sana_kunlar()[3], callback_data=f"3"),
#             InlineKeyboardButton(text=data.sana_kunlar()[4], callback_data=f"4"),
#             InlineKeyboardButton(text=data.sana_kunlar()[5], callback_data=f"5")
#         ],
#         [
#             InlineKeyboardButton(text=data.sana_kunlar()[6], callback_data=f"6")
#         ],
#         [
#             InlineKeyboardButton(text='◀️ Orqaga', callback_data='orqaga'),
#             InlineKeyboardButton(text='🏡 Bosh menu', callback_data='bosh_menu')            
#         ]
#     ]
# )


# inline_qarshi =  InlineKeyboardMarkup(
#     inline_keyboard=[
#         [
#             InlineKeyboardButton(text='◀️ Orqaga', callback_data='qarshi_xato')
#         ]
#     ]
# )

# inline_bosh_menu = InlineKeyboardMarkup(
#     inline_keyboard=[
#         [
#             InlineKeyboardButton(text='Qashqadaryo')
#         ]
#     ]
# )

# bosh_menu = ReplyKeyboardMarkup(
#     keyboard=[
#         [
#             KeyboardButton(text='Qashqadaryo vil')
#         ]
#     ],
#     resize_keyboard=True,
#     is_persistent=True
# )


# inline_hudud = InlineKeyboardMarkup(
#     inline_keyboard=[
#         [
#             InlineKeyboardButton(text='Qarshi', callback_data='qarshi')
#         ],
#         [
#             InlineKeyboardButton(text='Koson', callback_data='koson')
#         ],
#         [
#             InlineKeyboardButton(text='◀️ Orqaga', callback_data='orqaga'),
#             InlineKeyboardButton(text='🏡 Bosh menu', callback_data='bosh_menu')
#         ]
#     ]
# )