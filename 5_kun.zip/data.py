from datetime import datetime
import calendar

users = {
        '1923569602': {'name': 'Eshmatov Sardor', 'nomer': '+998889190506'},
        '7223024122': {'name': 'Eshmatov Sardor', 'nomer': '+998918119794'}
        }

polya_vaqt = {
    'kun_vaqt': {'kun': "29-Iyul", 'soat': '20:00-19:00', 'buyurtmachi': '1923569602', 'baza': users}
    }

user_info = users.get(str(1923569602), {})
print(users['1923569602'].get('nomer'))


def tek(polya_vaqt, data_v):
    for i in polya_vaqt:
        print(i, data_v)
        if i.split('-')[:-1] == data_v[:-1]:
            return True
        else:
            continue
    return False


def get_user(user_id):
    for user in users.keys():
        print(user, user_id)
        if user==user_id:
            return True
        else:
            continue
        
def buyurtma_gtv(polya_vaqt, user):
    for key, value in polya_vaqt.items():
        user_info = value['baza'][str(user)]
        k = f"Ma'lumotlar :\nOlindi: {value['kun']} soat : {value['soat']}\n\nBuyurtmachi:\n  Ismi: {user_info['name']}\n  Tel Nomer: {user_info['nomer']} lech( )"
    return k






#keraksiz ammo kerak bo'lib qoladi
def bugun():
    hozirgi_vaqt = datetime.now()
    oylar = [
        "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
        "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr"
    ]

    kun = hozirgi_vaqt.day
    oy = oylar[hozirgi_vaqt.month - 1]
    yil = hozirgi_vaqt.year

    hozirgi_vaqt_str = f"Bugun {kun} - {oy} - {yil} yil"

    return hozirgi_vaqt_str




