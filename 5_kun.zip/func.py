from aiogram import Bot
from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
import states
import keyboards
import data
import asyncio
import callback_func_tugma
async def start_xabari(message:Message, bot:Bot, state:FSMContext):
    print(message.from_user.id)
    print(data.get_user(str(message.from_user.id)))
    if data.get_user(str(message.from_user.id)):
        await message.delete()
        await message.answer(text=f"Qayerda o'ynamoqchisiz hududingizni tanlang..", reply_markup=keyboards.inline_hudud)
    else:
        await message.delete()
        await message.answer(text=f'Assalomu alaykum {message.from_user.first_name}\nBotdan to\'liq foydalanish uchun ismingizni kiriting \n\nNamuna: Eshmatov Sardor', reply_markup=ReplyKeyboardRemove())
        await state.set_state(states.sign_up.name)


async def get_nomer(message:Message, bot:Bot, state:FSMContext):
    if len(message.text.split())==2:
        await state.update_data(name=message.text)
        await message.reply(text=f'ismingiz qabul qilindi {message.text}')
        await message.answer(text='nomeringizni qoldiring \n\ntugmadan foydalaning : nomer ulashish', reply_markup=keyboards.contakt)
        await state.set_state(states.sign_up.nomer)
    else:
        await message.answer(text=f"Isim familya to'liq va to'g'ri bo'lishi shart\n\nNamuna: Eshmatov Sardor")
        await state.set_state(states.sign_up.name)


async def info_answer(message: Message, state: FSMContext):
    data1 = await state.get_data()
    data.users[str(message.from_user.id)] = {
        'name': data1.get('name'),
        'nomer': str(message.contact.phone_number)
    }
    phone = f"{message.contact.phone_number}"
    
    user_info = (
        f"📋 <b>Sizning ma'lumotlaringiz</b> 📋\n\n"
        f"👤 <b>Ismingiz: </b>{data1.get('name')}\n"
        f"📞 <b>Nomeringiz: </b>{phone}\n"
        f"💬 <b>Username: </b>@{message.from_user.username}"
    )
    
    progress_steps = [
        "█▒▒▒▒▒▒▒▒▒ 10%",
        "██▒▒▒▒▒▒▒▒ 20%",
        "███▒▒▒▒▒▒▒ 30%",
        "████▒▒▒▒▒▒ 40%",
        "█████▒▒▒▒▒ 50%",
        "██████▒▒▒▒ 60%",
        "███████▒▒▒ 70%",
        "████████▒▒ 80%",
        "█████████▒ 90%",
        "██████████ 100%",
        "✅ Tayyor!"
    ]
    vaqt = await message.answer(text='⏳',reply_markup=ReplyKeyboardRemove())

    txt = await message.answer('█▒▒▒▒▒▒▒▒▒ 0%')
    for i in progress_steps:
        # await asyncio.sleep(0.01)
        await txt.edit_text(text=i)
    
    await message.answer(
        text=user_info,
        parse_mode="HTML"
    )
    await message.answer(text="Qayerda o'ynamoqchisiz hududingizni tanlang..", reply_markup=keyboards.inline_hudud)
    await state.clear()


async def get_data(message:Message):
    malumot = f""
    for id, info in data.users.items():
        name = info['name']
        nomer = info['nomer']
        malumot+=f"ID: {id}\nIsm: {name}\nTelefon: {nomer}\n"
    await message.answer(malumot)





